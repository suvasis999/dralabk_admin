const adminsIds = ['633a0dc86b91a749f5d46fe0'];

module.exports = {adminsIds}
