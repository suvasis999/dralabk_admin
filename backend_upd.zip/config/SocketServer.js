const express = require( 'express' );
const server = express();
const socketApp = server;

module.exports = { socketApp };
