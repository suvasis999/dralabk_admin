const PROPS_FOR_USER_CHANGE_REQUEST = [ 'name', 'middle_name', 'last_name', 'dralla_wallet_adress', 'spirtual_name', 'sex', 'email', 'birth_date', 'adresse_line_1', 'adresse_line_2', 'state', 'city', 'zip_code', 'country', 'phone_number', 'image' ];

module.exports = { 'PROPS_FOR_USER_CHANGE_REQUEST': PROPS_FOR_USER_CHANGE_REQUEST };
